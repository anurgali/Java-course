package com.calculator.geometry;

public class AreaCalculator {

	float pi=3.14f;

	public static int area(int a, int b) {
		return a*b;
	}

	protected static void message(){
		System.out.println("Hello from AreaCalculator!");
	}
}
