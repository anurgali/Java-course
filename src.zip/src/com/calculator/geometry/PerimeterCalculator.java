package com.calculator.geometry;

public class PerimeterCalculator {

	float pi=3.14f;
	public static int perimeter (int a, int b) {
		return a*2+b*2;
	}

	public void testProtectedMethod(){
		AreaCalculator.message();
	}
}
