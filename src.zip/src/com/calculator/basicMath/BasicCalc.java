package com.calculator.basicMath;

import com.calculator.geometry.AreaCalculator;

public class BasicCalc {
	public String s = "";
	public static String k = "";

	//private
	//protected
	public static int add (int a, int b) {
		display(a, b);
		return a+b;
	}

	private static void display (int a, int b) {
		System.out.println("the numbers we want to add is: " + a + " and " + b);
	}

	public int subtract (int a, int b) {
		return a-b;
	}

	public int multiply (int a, int b) {
		return a*b;
	}

	public static void printString(){
		System.out.println(k);
	}


}
