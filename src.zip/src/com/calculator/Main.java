package com.calculator;

import com.calculator.basicMath.BasicCalc;
import com.calculator.geometry.AreaCalculator;
import com.calculator.geometry.PerimeterCalculator;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the first number: ");
		int a = sc.nextInt();
		System.out.print("Enter the second number: ");
		int b = sc.nextInt();
		System.out.println("a=" + a + ", b=" + b);
		Integer result = null;
		System.out.print("Enter the operation (+, -, area, perimeter): ");
		String operator = sc.next();
		if (operator.equals("+")) {
			result = BasicCalc.add(a, b);
		} else if (operator.equals("-")) {
			BasicCalc bc = new BasicCalc(); // instantiate an object using a default constructor
			//bc is an instance of an object
			result = bc.subtract(a,b);
		} else if (operator.equals("rectangle area")) { // pi*r^2
			result = AreaCalculator.area(a,b);
		} else if (operator.equals("perimeter")) { // 2*pi*r
			result = PerimeterCalculator.perimeter(a,b);
		} else {
			System.out.println("Unknown operator! Try again!");
		}
		System.out.println("result = " + result);


	}
}